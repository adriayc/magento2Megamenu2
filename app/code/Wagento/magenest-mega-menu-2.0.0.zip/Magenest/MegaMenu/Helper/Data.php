<?php
/**
 * Created by Magenest
 * User: Luu Thanh Thuy
 * Date: 22/04/2016
 * Time: 21:57
 */
namespace Magenest\MegaMenu\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{

    protected $_menuFactory;


    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magenest\MegaMenu\Model\MenuFactory $menuFactory
    ) {
        $this->_menuFactory = $menuFactory;
        parent::__construct($context);

    }//end __construct()


    public function getMenusArrayFormat()
    {

    }//end getMenusArrayFormat()
}//end class
