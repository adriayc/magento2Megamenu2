### Magento 2 Mega Menu

 Mega Menu is an extension for magento 2. Be inspired by the famous Wordpress menu,the module have visual menu builder allow
 admin create mega menu with ease and speed.
 
 We admin can add pages, category, custom link and arbitrary text to menu.  Use the Mega Menu you can
 create responsive, attractive menu . You can even have Map and Contact Form and Video on Mega Menu.
 
 

