<?php
/**
 * Created by Magenest
 * User: Luu Thanh Thuy
 * Date: 31/05/2016
 * Time: 00:35
 */
namespace Magenest\MegaMenu\Block\Menu;

class Menu extends \Magento\Catalog\Block\Product\NewProduct
{
    public function getNewsProducts($id)
    {
      //  $collection = parent::_getProductCollection()->addCategoriesFilter(['in'=>$id]);

     //   foreach ($collection as $product) {
       //     return $product->getId();

      //  }

    }
}
