<?php
/**
 * Created by Magenest
 * User: Luu Thanh Thuy
 * Date: 10/03/2016
 * Time: 03:16
 */

namespace Magenest\MegaMenu\Setup;

use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Eav\Setup\EavSetupFactory;

class InstallData implements InstallDataInterface
{

    private $megaSetupFactory;

    private $eavSetupFactory;


    /**
     * @param MegaSetupFactory $megaSetupFactory
     */
    public function __construct(
        \Magenest\MegaMenu\Setup\MegaSetupFactory $megaSetupFactory,
        EavSetupFactory $eavSetupFactory
    ) {
        $this->megaSetupFactory = $megaSetupFactory;

        $this->eavSetupFactory = $eavSetupFactory;

    }//end __construct()


    /**
     * Install data for a module
     *
     * @param  ModuleDataSetupInterface $setup
     * @param  ModuleContextInterface   $context
     * @return void
     */
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        /*
            @var \Magenest\MegaMenu\Setup\MegaSetup $megaSetup
        */
        $megaSetup = $this->megaSetupFactory->create(['setup' => $setup]);

        /*
            * Install eav entity types to the eav/entity_type table
         */
        $megaSetup->installEntities();
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'menu_featured',
            [
             'group'                   => 'Mega Menu',
             'type'                    => 'int',
             'backend'                 => 'Magento\Catalog\Model\Product\Attribute\Backend\Boolean',
             'frontend'                => '',
             'sort_order'              => 50,
             'label'                   => 'Featured product',
             'input'                   => 'select',
             'source'                  => 'Magento\Eav\Model\Entity\Attribute\Source\Boolean',
             'global'                  => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
             'visible'                 => true,
             'required'                => false,
             'user_defined'            => false,
             'default'                 => '',
             'searchable'              => false,
             'filterable'              => false,
             'comparable'              => false,
             'visible_on_front'        => false,
             'used_in_product_listing' => false,
             'unique'                  => false,
             'apply_to'                => 'simple,virtual,downloadable,configurable,bundle,grouped',
            ]
        );

    }//end install()
}//end class
