<?php
/**
 * Created by Magenest
 * User: Luu Thanh Thuy
 * Date: 09/03/2016
 * Time: 16:07
 */

namespace Magenest\MegaMenu\Setup;

use Magento\Eav\Model\Config;
use Magento\Eav\Model\Entity\Setup\Context;
use Magento\Eav\Setup\EavSetup;
use Magento\Framework\App\CacheInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Eav\Model\ResourceModel\Entity\Attribute\Group\CollectionFactory;

class MegaSetup extends \Magento\Eav\Setup\EavSetup
{

    /**
     * EAV configuration
     *
     * @var Config
     */
    protected $eavConfig;


    /**
     * Init
     *
     * @param ModuleDataSetupInterface $setup
     * @param Context                  $context
     * @param CacheInterface           $cache
     * @param CollectionFactory        $attrGroupCollectionFactory
     * @param Config                   $eavConfig
     */
    public function __construct(
        ModuleDataSetupInterface $setup,
        Context $context,
        CacheInterface $cache,
        CollectionFactory $attrGroupCollectionFactory,
        Config $eavConfig
    ) {
        $this->eavConfig = $eavConfig;
        parent::__construct($setup, $context, $cache, $attrGroupCollectionFactory);

    }//end __construct()


    /**
     * Retrieve default entities: customer, customer_address
     *
     * @return                                        array
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function getDefaultEntities()
    {
        $entities = [
                     'menu' => [
                                'entity_model'        => 'Magenest\MegaMenu\Model\ResourceModel\Menu',
                                'table'               => 'magenest_megamenu_entity',
                                'increment_model'     => 'Magento\Eav\Model\Entity\Increment\NumericValue',
                                'increment_per_store' => true,
                                'attributes'          => [
                                                          'effect'      => [
                                                                            'type'       => 'text',
                                                                            'label'      => 'Animation Effect',
                                                                            'input'      => 'text',
                                                                            'sort_order' => 10,
                                                                            'position'   => 10,
                                                                           ],
                                                          'html_before' => [
                                                                            'type'       => 'text',
                                                                            'label'      => 'HTML Before',
                                                                            'input'      => 'text',
                                                                            'sort_order' => 20,
                                                                            'position'   => 20,
                                                                           ],
                                                          'html_before' => [
                                                                            'type'       => 'text',
                                                                            'label'      => 'HTML After',
                                                                            'input'      => 'text',
                                                                            'sort_order' => 30,
                                                                            'position'   => 40,
                                                                           ],
                                                         ],
                               ],
                    ];
        return $entities;

    }//end getDefaultEntities()
}//end class
