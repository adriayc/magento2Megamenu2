<?php
/**
 * Created by Magenest
 * User: Luu Thanh Thuy
 * Date: 09/03/2016
 * Time: 15:54
 */
namespace Magenest\MegaMenu\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

class InstallSchema implements InstallSchemaInterface
{


    /**
     * {@inheritdoc}
     *
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();

        /*
            * Create table 'customer_entity'
         */
        $table = $installer->getConnection()->newTable(
            $installer->getTable('magenest_menu_entity')
        )->addColumn(
            'entity_id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            [
             'identity' => true,
             'unsigned' => true,
             'nullable' => false,
             'primary'  => true,
            ],
            'Entity Id'
        )->addColumn(
            'website_id',
            \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT,
            null,
            ['unsigned' => true],
            'Website Id'
        )->addColumn(
            'title',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            255,
            [],
            'Name'
        )->addColumn(
            'level',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            ['unsigned' => true],
            'Level'
        )->addColumn(
            'sort',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            ['unsigned' => true],
            'Order'
        )->addColumn(
            'parent_id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            [
             'unsigned' => true,
             'nullable' => false,
             'default'  => '0',
            ],
            'Parent Id'
        )->addColumn(
            'parent_id_temp',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            [
             'unsigned' => true,
             'nullable' => false,
             'default'  => '0',
            ],
            'Parent Id'
        )->addColumn(
            'id_temp',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            [
             'unsigned' => true,
             'nullable' => false,
             'default'  => '0',
            ],
            'Parent Id'
        )->addColumn(
            'brother_name',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            null,
            [ 'nullable' => true],
            'Brother name'
        )->addColumn(
            'children',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'Children Id'
        )->addColumn(
            'store_id',
            \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT,
            null,
            [
             'unsigned' => true,
             'default'  => '0',
            ],
            'Store Id'
        )->addColumn(
            'created_at',
            \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
            null,
            [
             'nullable' => false,
             'default'  => \Magento\Framework\DB\Ddl\Table::TIMESTAMP_INIT,
            ],
            'Created At'
        )->addColumn(
            'updated_at',
            \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
            null,
            [
             'nullable' => false,
             'default'  => \Magento\Framework\DB\Ddl\Table::TIMESTAMP_INIT_UPDATE,
            ],
            'Updated At'
        )->addColumn(
            'is_active',
            \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT,
            null,
            [
             'unsigned' => true,
             'nullable' => false,
             'default'  => '1',
            ],
            'Is Active'
        )->addColumn(
            'is_mega',
            \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT,
            null,
            [
             'unsigned' => true,
             'nullable' => false,
             'default'  => '1',
            ],
            'Is Mega Menu'
        )->addColumn(
            'megaColumn',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            [
             'unsigned' => true,
             'nullable' => false,
            ],
            'column of sub mega menu'
        )->addColumn(
            'is_top',
            \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT,
            null,
            [
             'unsigned' => true,
             'nullable' => false,
             'default'  => '1',
            ],
            'Is Top Menu'
        )->addColumn(
            'type',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            null,
            ['nullable' => true],
            'Type'
        )->addColumn(
            'comment',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'Comment'
        )->addColumn(
            'css',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '2M',
            [
             'nullable' => true,
             'default'  => null,
            ],
            'custom css'
        )->addColumn(
            'label_color',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            null,
            [
             'nullable' => true,
             'default'  => null,
            ],
            'label color'
        )->addColumn(
            'label_name',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            null,
            [
             'nullable' => true,
             'default'  => null,
            ],
            'label name'
        )->addColumn(
            'icon',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            255,
            [],
            'Icon'
        )
            ->addColumn(
            'background_image',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            255,
            [],
            'Background image'
        )->addColumn(
            'link',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'Link of custom link menu type'
        )->addColumn(
            'obj_id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            [
             'unsigned' => true,
             'nullable' => true,
             'default'  => '0',
            ],
            'Entity id of page or category'
        )->addColumn(
            'include_child',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            255,
            [],
            'Include child for category menu'
        )->addColumn(
            'show_product',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            255,
            [],
            'Show New arrival or best seller of category'
        )->setComment(
            'Menu Entity'
        );
        $installer->getConnection()->createTable($table);
        $installer->endSetup();

    }//end install()
}//end class
