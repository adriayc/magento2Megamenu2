<?php
/**
 * Created by Magenest
 * User: Luu Thanh Thuy
 * Date: 09/03/2016
 * Time: 16:21
 */
namespace Magenest\MegaMenu\Controller\Adminhtml\Menu;

use Magento\Framework\App\ResponseInterface;

class Save extends \Magento\Backend\App\Action
{

    protected $_menuFactory;


    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magenest\MegaMenu\Model\MenuFactory $menuFactory
    ) {
        parent::__construct($context);
        $this->_menuFactory = $menuFactory;

    }//end __construct()


    /**
     * Dispatch request
     *
     * @return \Magento\Framework\Controller\ResultInterface|ResponseInterface
     * @throws \Magento\Framework\Exception\NotFoundException
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();

        $params = $this->getRequest()->getParams();

        $deleteItemsStr = $this->getRequest()->getParam('remove_items');

        if ($deleteItemsStr) {
            $deleteItems = explode(',', $deleteItemsStr);
            if (is_array($deleteItems) && !empty($deleteItems)) {
                foreach ($deleteItems as $menuId) {
                    $menu = $this->_menuFactory->create()->load($menuId);

                    if ($menu->getId()) {
                        $menu->delete();
                    }
                }
            }
        }

        /*
            save a menu with information of id, title, level, order ,parentId
        */

        $newIds = [];

        $updateParents = [];

        if (!isset($params['menu'])) {
            return $resultRedirect->setPath('*/*/');
        };

        $menuParams = $params['menu'];


        $editMode = false;

        foreach ($menuParams as $rawData) {
            $menuData   = [
                'id'            => 0,
                'title'         => '',
                'level'         => 0,
                'sort'          => 0,
                'parentId'      => 0,
                'type'          => '',
                'entity_id'     => 0,
                'is_mega'       => '',
                'is_top'        => '',
                'type'          => '',
                'parent_id'     => '',
                'link'          => '',
                'obj_id'        => '',
                'brother_name'  => '',
                'icon'          => '',
                'id_temp'       => '',
                'label_color'   => '',
                'label_name'    => '',
                'megaColumn'    => 6,
                'include_child' => '',
                'show_product'  => '',
            ];
            if (isset($rawData['is_new']) && $rawData['is_new'] == 'false') {
                $editMode = true;
            } else {
                $editMode = false;
            }

            foreach ($menuData as $key => $value) {
                if (isset($rawData[$key])) {
                    $menuData[$key] = $rawData[$key];
                }
            }

            if (isset($rawData['id'])) {
                $menuData['entity_id'] = $rawData['id'];
                $menuData['id_temp']   = $rawData['id'];
            }

            if (!$editMode) {
                unset($menuData['entity_id']);
                unset($menuData['id']);
            }

            $menu = $this->save($menuData);

            $parentId = $menu->getData('parent_id');

            $parentMenu = $this->_menuFactory->create()->getCollection()->addFieldToFilter('entity_id', $parentId);

            if ($parentMenu->getSize() == 0) {
                $updateParents[] = $menu->getId();
            }

            if (!$editMode) {
                $newIds[] = $menu->getId();
            }
        }//end foreach

        // update the real parent id
        if (!empty($updateParents)) {
            foreach ($updateParents as $id) {
                $menu = $this->_menuFactory->create()->load($id);

                $parentId      = $menu->getData('parent_id');
                $parentMenuCol = $this->_menuFactory->create()->getCollection()->addFieldToFilter('id_temp', $parentId);
                if ($parentMenuCol->getSize() > 0) {
                    $parentMenu = $parentMenuCol->getFirstItem();

                    $realParentId = $parentMenu->getId();
                    $menu->addData(['parent_id' => $realParentId])->save();
                }
            }
        }

        return $resultRedirect->setPath('*/*/');

    }//end execute()


    public function save($menuData)
    {
        return $this->_menuFactory->create()->setData($menuData)->save();

    }//end save()
}//end class
