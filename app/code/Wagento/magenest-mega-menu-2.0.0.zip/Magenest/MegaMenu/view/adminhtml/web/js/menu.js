define([
    "jquery",
    "ko",
    "uiClass",
    'mage/url',
    'Magento_Ui/js/lib/spinner',
    "Magento_Ui/js/modal/modal",
    'jquery/file-uploader',
    "Magenest_MegaMenu/js/menu",
    "underscore"
], function ($, ko,Class,url,loader,modal,fileupload, menu, _) {
    "use strict";
    ko.bindingHandlers.visualmenubuilder = {

        /**
         * Scope binding's init method.
         * @returns {Object} - Knockout declaration for it to let binding control descendants.
         */
        init: function () {
            return {
                controlsDescendantBindings: true
            };
        }
    };


    /**
     *
     * @type {{init: Function, update: Function}}
     */
    ko.bindingHandlers.mmfileupload= {
        init: function(element, valueAccessor,allBindings, viewModel, bindingContext) {
            $(element).fileupload({  dataType: 'json',
                done: function (e, data) {
                    var imagePath = data.result.url;
                    viewModel.image(imagePath);
                }});
        },
        update: function(element, valueAccessor,allBindings, viewModel, bindingContext) {

        }
    };
    /**
     *
     * @type {{init: Function}}
     */
    ko.bindingHandlers.mmaccordion = {

        /**
         * Scope binding's init method.
         * @returns {Object} - Knockout declaration for it to let binding control descendants.
         */
        init: function (element, valueAccessor,allBindings, viewModel, bindingContext) {
            var icons = {
                header: "icon-arrow-up",
                activeHeader: "icon-arrow-down"
            };
            $(element).accordion({
                active: true,
                collapsible: true,
                heightStyle: "content",
                icons: icons
            });
        }
    };
    /**
     *
     * @type {{init: Function}}
     */
    ko.bindingHandlers.mmdragdrop = {

        /**
         * Scope binding's init method.
         * @returns {Object} - Knockout declaration for it to let binding control descendants.
         */
        init: function (element, valueAccessor,allBindings, viewModel, bindingContext) {
            $(element).draggable({

                revert: function(dropped)
                {
                    return true;

                }
            });
        }
    };


    function updateBrother (e) {
        var   liE = $(e);
        var currentLevel =  $(e).data('level');
        var sameLevelSelector = 'li[data-level="' + currentLevel + '"]';
        var prevLiE = liE.prevUntil('ul').filter(function(index, element) {
            var level = parseInt($(this).attr('data-level'));
            if (level == currentLevel || level < currentLevel){


                return true;
            }
        }).first();
        if (prevLiE.length > 0) {
            liE.attr('has_brother' , 'true');
            var brother_name =prevLiE.find('span[data-role="title"]').first().html();
            var eInputBrother = liE.find('input[data-role="brother"]');
            eInputBrother.val(brother_name);
            //liE.data('brother_name' );
        }
    }

    /* Page model */

    function Page(data) {
        var self = this;
        this.title = ko.observable(data.title);
        this.page_id  = ko.observable(data.page_id);
        this.link = ko.observable(data.link);

    }

    /* Page model */

    function Cat(data) {
        var self = this;
        this.title = ko.observable(data.title);
        this.id  = ko.observable(data.entity_id);
        this.link = ko.observable(data.link);

    }

    //mega menu
    function Menu(data) {
        var self = this;
        this.id = ko.observable(data.id);
        this.title = ko.observable(data.title);
        this.sort = ko.observable(data.sort);
        this.level = ko.observable(data.level);
        this.parent =  ko.observable(data.parent);
        this.parentNode = ko.observable(data.parentNode);
        this.childNode = ko.observable(data.childNode);
        this.hasParent =  ko.observable(data.hasParent);
        this.parentName=ko.observable(data.parentName);

        this.hasBrother =  ko.observable(data.hasBrother);
        this.brother_name =  ko.observable(data.brother_name);

        this.label_name =  ko.observable(data.label_name);
        this.label_color =  ko.observable(data.label_color);
        this.is_mega =  ko.observable(data.is_mega);

        this.open_setting =  ko.observable('in-active');

        // this.isMega=ko.observable(data.isMega);;
        // this.isMega=ko.observable(1);
        this.megaColumn=ko.observable(data.megaColumn);


        this.type = ko.observable(data.type);
        this.obj_id = ko.observable(data.obj_id);
        this.link = ko.observable(data.link);
        this.is_new = ko.observable(data.is_new);

        this.needUpdateBrother = ko.observable(false);

        this.image = ko.observable(data.image);

        //particular for category

        this.include_child = ko.observable(data.include_child);
        this.show_product = ko.observable(data.show_product);


        this.downOneCol = function(menu, event) {
            event.stopPropagation();
            var oldValue =  parseInt( ko.unwrap(menu.megaColumn));
            if (isNaN(oldValue)) oldValue =0;
            if (oldValue >2  )
                menu.megaColumn (oldValue - 1);

        };
        this.upOneCol = function(menu, event) {
            event.stopPropagation();
            var oldValue =  parseInt( ko.unwrap(menu.megaColumn));
            if (isNaN(oldValue)) oldValue =0;
            if (oldValue < 12  )
                menu.megaColumn (oldValue + 1);

        };

        //go under brother menu

        this.downOne = function(menu, event) {
            var isHaveChildrens = false;
            //self.parent(1000);
            var liE = $(event.target).closest('li');
            liE.attr('data-move' , '1');

            var currentLevel =  ko.unwrap(menu.level);

            var parentLevel = parseInt(currentLevel) -1;

            var nextLiE = liE.nextUntil('ul').filter(function(index, element) {
                var level = parseInt($(this).attr('data-level'));
                if (level == currentLevel || level < currentLevel){
                    $(this).attr('data-insertbefore' , '1');

                    return true;
                }
            }).first();


            var childrensOfLi = liE.nextUntil(nextLiE).filter(function(index, element) {
                $(this).attr('data-move' , '1');
                isHaveChildrens = true;
            });

            if (nextLiE.length > 0) {
                $('li[data-move="1"]').insertAfter(nextLiE);

                $('li').attr('data-move' ,0);
            }

            // liE.insertAfter(nextLiE);

            var newParentSelector = 'li[data-level="' + parentLevel + '"]';


            var newParentEf = liE.prevUntil('ul').filter(function(index, element) {
                var level = parseInt( $(this).data('level') );
                if (level < currentLevel) return true;

            }).first();

            //maybe there is no parent for the li after move
            if (newParentEf.length > 0) {
                var parent = newParentEf.attr('data-id');

                var parentName = newParentEf.attr('data-title');

                var afterMoveLevel = parseInt(newParentEf.data('level')) + 1;


                //calculate the parent of the menu
                //calculate the level
                //update the sort order of all
                menu.parent(parent);
                menu.level(afterMoveLevel);

                if (parseInt(parent) > 0) menu.hasParent(true);
                menu.parentName(parentName);
            } else {
                menu.parent(0);
                menu.level(0);
                menu.hasParent(false);
            }

            menu.needUpdateBrother(true);

        }  ;

        this.upOne = function(menu, event) {
            //there are variables : isFistChildren, isBottom, isToTop, isHaveChildrens. isChangeParent
            var  isFistChildren, isToTop, isHaveChildrens, isChangeParent;

            var isBottom = false;
            var liE = $(event.target).closest('li');
            liE.attr('data-move' , '1');
            liE.attr('data-currentTarget' , '1');
            var currentLevel =  ko.unwrap(menu.level);

            var parentLevel = parseInt(currentLevel) -1;

            var sameLevelSelector = 'li[data-level="' + currentLevel + '"]';

            var nextLiE = liE.prevUntil('ul',sameLevelSelector).first();
            var nextLiE = liE.prevUntil('ul').filter(function(index, element) {
                var level = parseInt($(this).attr('data-level'));
                if (level == currentLevel || level < currentLevel){
                    $(this).attr('data-insertbefore' , '1');

                    return true;
                }
            }).first();

            //determine that it is first Children of a menu
            var prevLiElement = liE.prev();

            if (prevLiElement.length > 0 ) {
                var prevLevel =  parseInt(prevLiElement.attr('data-level') );

                if (prevLevel == currentLevel -1) {
                    isFistChildren = true;
                }
            }


            var duoiLiE = liE.nextUntil('ul').filter(function(index, element) {
                var level = parseInt($(this).attr('data-level'));
                if (level == currentLevel || level < currentLevel){
                    $(this).attr('data-insertbefore' , '1');

                    return true;
                }
            }).first();


            var childrensOfLi = liE.nextUntil(duoiLiE).each(function() {
                $(this).attr('data-move' , '1');
                isHaveChildrens = true;
            }) ;
            if (nextLiE.length > 0) {
                $('li[data-move="1"]').insertBefore(nextLiE);

                $('li').attr('data-move' ,0);
            } else if(isFistChildren && prevLiElement.length > 0)  {

                $('li[data-move="1"]').insertBefore(prevLiElement);
                $('li').attr('data-move' ,0);
            }


            var newParentSelector = 'li[data-level="' + parentLevel + '"]';

            //if the item level 2 now become right after an item level 0 then item level 2 become level 1


            var newParentE = liE.prevUntil('ul').filter(function(index, element) {
                var level = parseInt( $(this).data('level') );
                if (level < currentLevel) return true;

            }).first();

            if (newParentE.length > 0) {
                var parent = newParentE.attr('data-id');

                var parentName = newParentE.attr('data-title');

                var parentLevel = newParentE.data('level');
                //calculate the parent of the menu
                //calculate the level
                //update the sort order of all
                menu.parent(parent);
                menu.level(parentLevel + 1);

                if (parseInt(parent) > 0) menu.hasParent(true);
                menu.parentName(parentName);


                //if the menu is move to top of menu
                if (liE.is(":first-child")) {
                    menu.level('0');

                    menu.parent('0');

                    menu.hasParent(false);
                    menu.parentName('');
                }

            } else {
                menu.level('0');

                menu.parent('0');

                menu.hasParent(false);
                menu.parentName('');
            }


            liE.attr('data-currentTarget' , '0');
            menu.needUpdateBrother(true);
        };
    }

    function MenuViewModel($config) {
        var self = this;
        self.config = $config;
        self.menus = ko.observableArray([]);
        self.newMenuText = ko.observable();

        self.pages = ko.observableArray([]);
        self.cats = ko.observableArray([]);

        self.custom_link_title = ko.observable();
        self.custom_link_link = ko.observable();

        self.custom_text_title = ko.observable();
        self.custom_text_link = ko.observable();

        self.chosenCats =  ko.observableArray([]);

        //seletced Cats is mapping from chosenCats via checkCat function

        self.selectedCats =  ko.observableArray([]);

        self.removedItems = ko.observableArray([]);

        self.serializedRemovedItems = ko.pureComputed(function ( ){
            var serializedr='' ;
            ko.utils.arrayForEach(self.removedItems() ,function(item,i) {
                if (i ===0) {
                    serializedr = item + ',';
                } else if (i > 0 && i < self.removedItems().length-1 ) {
                    serializedr = serializedr + item + ',';
                } else {
                    serializedr = serializedr + item;
                }


            }) ;

            return serializedr;
        },self) ;
        self.pageLoading = ko.observable(true);
        self.catLoading = ko.observable(true);
        self.menuLoading = ko.observable(true);
        self.isLoading = ko.pureComputed( function() {
            if (!self.pageLoading()  && !self.catLoading() && !self.menuLoading() ) {
                return false;
            } else {
                return true;
            }

        });




        self.needUpdate = ko.computed(function(){
            var total = 0;
            ko.utils.arrayForEach(self.menus(), function(item) {

                if (item.needUpdateBrother()) {
                    self.updateBrother();
                    item.needUpdateBrother(false);
                }

            });
            return total;
        });
        // Operations

        /**
         * Remove the menu from the main menu
         * If a menu has childrens, user remove it will remove all its childrens
         * @param menu
         */
        self.removeMenu = function(menu,event) {
            event.stopPropagation();

            //need to remove the menu and all its childrens
            var menuId = menu.id();

            var currentLevel = menu.level();

            //find the down limit of the menu
            var targetSelector = 'li[data-id=' + '"' + menuId + '"]';
            var targetLi = $(targetSelector).first();

            var nextElementLimitor = targetLi.nextUntil('ul').filter(function(index, element) {
                var level = parseInt($(this).attr('data-level'));
                if (level == currentLevel || level < currentLevel){
                    return true;
                }
            }).first();

            if (nextElementLimitor.length > 0) {
                var childrensOfLi = targetLi.nextUntil(nextElementLimitor).each(function() {
                    var childrenId =    $(this).data('id');
                    ko.utils.arrayForEach(self.menus(), function(item) {

                        if (item.id() == childrenId) {
                            self.removedItems.push(item.id());
                            self.menus.destroy(item);

                        }

                    });
                }) ;
            }

            //if the removed item has childrens and it is in the bottom

            if (nextElementLimitor.length ==0) {
                var childrensOfLi =  targetLi.nextUntil('ul').filter(function(index, element) {
                    var level = parseInt($(this).attr('data-level'));
                    if (level >  currentLevel){
                        return true;
                    }
                });

                if (childrensOfLi.length > 0 ) {
                    var childrenId =    $(this).data('id');
                    ko.utils.arrayForEach(self.menus(), function(item) {

                        if (item.id() == childrenId) {
                            self.removedItems.push(item.id());
                            self.menus.destroy(item);

                        }

                    });
                }

            }

            self.removedItems.push(menu.id());


            self.menus.destroy(menu)
            self.updateBrother();

        }

        //add category link to menu
        self.addCategoryLinkToMenu = function() {
            ko.utils.arrayForEach(self.selectedPage(), function (page) {
                self.menus.push (new Menu({
                    id: page.id,
                    is_new : true,
                    title: page.name,
                    level: 0,
                    sort:100,
                    hasParent:false,
                    type: page.type,
                    obj_id : page.obj_id
                })) ;

            }) ;

            self.updateBrother();
        }

        //add custom link to menu
        self.addCustomLinkToMenu = function() {
            var menuIds  = $.map(self.menus(), function(menu){ return menu.id(); });
            var maxId;
            if (menuIds.length ==0) {
                var maxId = 1;
            } else {
                var maxId = Math.max.apply(this, menuIds);
                maxId++;
            }
            self.menus.push (new Menu({
                id: maxId,
                is_new : true,
                title:self.custom_link_title(),
                level: 0,
                sort:100,
                hasParent:false,
                type: 'link',
                obj_id : 0,
                link : self.custom_link_link()
            })) ;

            self.updateBrother();
        }

        self.addCustomTextToMenu = function() {
            var menuIds  = $.map(self.menus(), function(menu){ return menu.id(); });
            var maxId;
            if (menuIds.length ==0) {
                var maxId = 1;
            } else {
                var maxId = Math.max.apply(this, menuIds);
                maxId++;
            }
            self.menus.push (new Menu({
                id: maxId,
                is_new : true,
                title:self.custom_text_title(),
                level: 0,
                sort:100,
                hasParent:false,
                type: 'text',
                obj_id : 0,
                link : self.custom_text_link()
            })) ;

            self.updateBrother();
        }

        self.megaSetting = function($menu, $event) {
            var config_status =  $menu.open_setting();
            var spanE = $(event.target);
            var targetId = spanE.data('setting');
            var megaSettingSelector = 'div[data-settingwrapper="'+ targetId + '"]';

            if (config_status =='in-active') {

                $menu.open_setting('active');
                $(megaSettingSelector).show();

            } else {
                $menu.open_setting('in-active');
                $(megaSettingSelector).hide();

            }


        }

        self.toggleSelectedPage = function(item) {
            if (item.Selected() === true) {
            } else {
                item.Selected(!(item.Selected()));
            }

            return true;
        }
        self.chosenPages = ko.observableArray([]);
        self.selectedPage = ko.observableArray([]);


        self.checkPage = function ($page, $event) {
            self.selectedPage().length = 0;

            var menuIds  = $.map(self.menus(), function(menu){ return menu.id(); });
            var maxId;
            if (menuIds.length ==0) {
                var maxId = 1;
            } else {
                var maxId = Math.max.apply(this, menuIds);
                maxId++;
            }

            var page_id = ko.unwrap($page.page_id);
            var name;
            ko.utils.arrayForEach(self.chosenPages(), function(id) {
                ko.utils.arrayForEach(self.pages(), function(pid) {
                    if (id == pid.page_id())
                        name = pid.title();

                });
                self.selectedPage.push ({id: maxId, name: name , parent: 0, level : 0 , type: 'page' , obj_id: id}) ;
                maxId++;
            });


            return true;
        }

        /**
         * mapping  chosenCats to the refined Categories
         */
        self.checkCat = function ($cat,$event) {
            self.selectedCats().length = 0;

            var menuIds  = $.map(self.menus(), function(menu){ return menu.id(); });
            var maxId;
            if (menuIds.length ==0) {
                var maxId = 1;
            } else {
                var maxId = Math.max.apply(this, menuIds);
                maxId++;
            }

            var name;
            ko.utils.arrayForEach(self.chosenCats(), function(id) {
                ko.utils.arrayForEach(self.cats(), function(cat) {
                    if (id == cat.id())
                        name = cat.title();

                });
                self.selectedCats.push ({id: maxId, name: name , parent: 0, level : 0 , type: 'category' , obj_id: id}) ;
                maxId++;
            });


            return true;
        }

        //this is invoked when user click add categories to menu
        self.addCategoryLinkToMenu = function( ) {

            var userCat = self.chosenCats();
            ko.utils.arrayForEach(self.selectedCats(), function (cat) {
                self.menus.push (new Menu({
                    id: cat.id,
                    is_new : true,
                    title: cat.name,
                    level: 0,
                    sort:100,
                    hasParent:false,
                    type: cat.type,
                    obj_id : cat.obj_id
                })) ;

            }) ;

            self.updateBrother();
        }

        /**
         * remove icon image of a menu
         * @param menu
         */
        self.removeImage = function(menu) {
            menu.image("");

        }

        /**
         * User click to out of Home for example to take menu and all of its childrens out of Home
         * @param menu
         * @param event
         */
        self.outParent = function(menu, event) {
            var liE = $(event.target).closest('li');
            var outMenuArr = new Array();

            liE.attr('data-outparent' , '1');
            var currentLevel =  ko.unwrap(menu.level);

            var parentLevel = parseInt(currentLevel) -1;
            var sameLevelSelector = 'li[data-level="' + currentLevel + '"]';

            var duoiLiE = liE.nextUntil('ul').filter(function(index, element) {
                var level = parseInt($(this).attr('data-level'));
                if (level == currentLevel || level < currentLevel){
                    $(this).attr('data-nextsiblings' , '1');

                    return true;
                }
            }).first();


            var childrensOfLi = liE.nextUntil(duoiLiE).each(function() {
                $(this).attr('data-outparent' , '1');
            }) ;

            //decrease all the outparent 1 level , for example from 2 to 1


            //change the menus of model
            ko.utils.arrayForEach( self.menus(), function(menu) {

                var menuId = menu.id();


                //loop through the out-of-parents menu
                $('li[data-outparent="1"]').each(function(i,e) {
                    var menuIdOfLi = $(this).data('id');

                    outMenuArr.push(menuIdOfLi);

                    var theLevel = $(e).data('level');
                    var newLevel = parseInt(theLevel) - 1;
                    if (menuIdOfLi ==menuId) {

                        menu.level(newLevel);
                    }

                });

            });

            $('li[data-outparent="1"]').attr('data-outparent' ,'0');

            self.updateBrother();
        }

        this.goUnder = function(menu, event) {
            // var self = this;

            $('li[data-insertbefore="1"]').data('insertbefore','0');

            var liE = $(event.target).closest('li');
            //there are variables : isFistChildren, isBottom, isToTop, isHaveChildrens. isChangeParent
            var  isFistChildren, isToTop, isHaveChildrens, isChangeParent;

            var isBottom = false;
            var liE = $(event.target).closest('li');
            liE.attr('data-move' , '1');
            liE.attr('data-currentTarget' , '1');
            var currentLevel =  ko.unwrap(menu.level);

            var parentLevel = parseInt(currentLevel) -1;

            var sameLevelSelector = 'li[data-level="' + currentLevel + '"]';

            var nextLiE = liE.prevUntil('ul').filter(function(index, element) {
                var level = parseInt($(this).attr('data-level'));
                if (level == currentLevel ){

                    return true;
                }
            }).first();
            var  PrevToInsert = nextLiE;
            nextLiE.attr('data-insertbefore' , '1');

            var childrenOfPrev = nextLiE.nextUntil(liE).last();

            if (childrenOfPrev.length > 0) {
                PrevToInsert=childrenOfPrev;
            }



            //determine that it is first Children of a menu
            var prevLiElement = liE.prev();

            if (prevLiElement.length > 0 ) {
                var prevLevel =  parseInt(prevLiElement.attr('data-level') );

                if (prevLevel == currentLevel -1) {
                    isFistChildren = true;
                }
            }

            var duoiLiE = liE.nextUntil('ul').filter(function(index, element) {
                var level = parseInt($(this).attr('data-level'));
                if (level == currentLevel || level < currentLevel){
                    $(this).attr('data-insertbefore' , '1');

                    return true;
                }
            }).first();


            var childrensOfLi = liE.nextUntil(duoiLiE).each(function() {
                $(this).attr('data-move' , '1');
                isHaveChildrens = true;
            }) ;

            //action to move the li and its children
            if (nextLiE.length > 0) {
                $('li[data-move="1"]').insertAfter(PrevToInsert);


            } else if(isFistChildren && prevLiElement.length > 0)  {

                $('li[data-move="1"]').insertAfter(prevLiElement);

            }

            //increase the level by one
            $('li[data-move="1"]').each(function(i,e) {
                var theLevel = $(e).data('level');
                var newLevel = parseInt(theLevel) + 1;
                currentLevel = newLevel;
                $(e).data('level',newLevel);
                parentLevel = newLevel-1;
                var idMenu = $(e).data('id');
                //update the level of knockout

                ko.utils.arrayForEach( self.menus(), function(menu) {
                    var menuId = menu.id();
                    if (menuId == idMenu) {
                        menu.level(newLevel) ;
                    }
                });
            }) ;

            $('li').attr('data-move' ,0);

            var newParentSelector = 'li[data-level="' + parentLevel + '"]';


            // var newParentE = liE.prevUntil('ul',newParentSelector).first();

            //if the item level 2 now become right after an item level 0 then item level 2 become level 1


            var newParentE = liE.prevUntil('ul').filter(function(index, element) {
                var level = parseInt( $(this).data('level') );
                if (level < currentLevel) return true;

            }).first();

            var parent = newParentE.attr('data-id');

            var parentName = newParentE.attr('data-title');

            var parentLevel = newParentE.data('level');
            //calculate the parent of the menu
            //calculate the level
            //update the sort order of all
            menu.parent(parent);
            // menu.level(parentLevel + 1);

            if (parseInt(parent) > 0) menu.hasParent(true);
            menu.parentName(parentName);


            //if the menu is move to top of menu
            if (liE.is(":first-child")) {
                menu.level('0');

                menu.parent('0');

                menu.hasParent('false');
                menu.parentName('');
            }

            liE.attr('data-currentTarget' , '0');
            $('li[data-insertbefore="1"]').attr('data-insertbefore','0');;
            self.updateBrother();

        }


        self.addMenu = function() {
            self.menus.push(new Menu({ title: this.newMenuText() }));
            self.newTaskText("");
        };


        self.save = function() {
            //calculate the order of all menu items
            $('ul[data-role="menu-container"] li').each(function(i,e) {
                // alert(i);
                var updatedOrder = i + 1;
                var eInputOrder = $(e).find('input[data-role="sort"]');
                var orderVal = $(eInputOrder).val(updatedOrder);
                //alert ($(eInputOrder).val());

            });

            //calculate the previous menu to have link "Under the Home" for example

            $('#menu_form').submit();
            /* $.ajax("<?php echo $block->getUrl('menu/menu/save', ['form_key' =>$block->getFormKey()]) ?>", {
             data: ko.toJSON({ tasks: self.menus}),
             type: "post", contentType: "application/json",
             success: function(result) { alert(result) }
             });*/
        };

        //action trigger when click Button is added
        self.btnAdd = function ( data, event) {
            ko.utils.arrayForEach(self.selectedPage(), function (page) {
                self.menus.push (new Menu({
                    id: page.id,
                    is_new : true,
                    title: page.name,
                    level: 0,
                    sort:100,
                    hasParent:false,
                    type: page.type,
                    obj_id : page.obj_id
                })) ;

            }) ;

            self.updateBrother();
        }

        //add category in the Menu


        //update the brother name

        self.updateBrother = function() {
            self = this;

            $('ul[data-role="menu-container"]').find('li').each(function(i,e) {
                var   liE = $(e);
                var menuIdOfE = liE.data('id');

                var currentLevel =  $(e).data('level');

                var sameLevelSelector = 'li[data-level="' + currentLevel + '"]';
                var prevLiE = liE.prevUntil('ul').filter(function(index, element) {
                    var level = parseInt($(element).attr('data-level'));
                    if (level == currentLevel ){


                        return true;
                    }
                }).first();
                if (prevLiE.length > 0) {
                    liE.attr('has_brother' , 'true');
                    var brother_name =prevLiE.find('span[data-role="title"]').first().html();
                    var eInputBrother = liE.find('input[data-role="brother"]');
                    // eInputBrother.val(brother_name);

                    ko.utils.arrayForEach(self.menus(), function(menu) {
                        if (menuIdOfE == menu.id()) {
                            menu.hasBrother(true);
                            menu.brother_name(brother_name);
                        }

                    })
                    //liE.data('brother_name' );
                } else {
                    ko.utils.arrayForEach(self.menus(), function(menu) {
                        if (menuIdOfE == menu.id()) {
                            menu.hasBrother(false);
                            menu.brother_name(undefined);
                        }

                    })
                }
            })
        },

            self.dragAndDrop =function (self)
            {

                $('ul[data-role="menu-container"]').droppable({
                    drop: function( event, ui ) {

                        console.log(event);
                        console.log(ui);
                        var calArr = new Array();
                        var dropE =   ui.draggable;
                        var  childrensOfLi;
                        var positiondropE = dropE.offset();
                        var topD = positiondropE.top;

                        var leftD = positiondropE.left;

                        var levelD = dropE.data('level');

                        var idD = dropE.attr('id');
                        var dataIdD = dropE.attr('data-id');

                        var duoiLiE = dropE.nextUntil('ul').filter(function(index, element) {
                            var level = parseInt($(this).attr('data-level'));
                            if (level == levelD || level < levelD){
                                return true;
                            }
                        }).first();

                        if (duoiLiE.length > 0)
                        {
                            var childrensOfLi = dropE.nextUntil(duoiLiE).each(function() {
                                $(this).attr('need-move' , '1');

                            })
                        } else {
                            var childrensOfLi = dropE.nextUntil('ul').each(function() {
                                var level = parseInt($(this).attr('data-level'));
                                if ( level > levelD){
                                    $(this).attr('need-move' , '1');

                                    return true;
                                }

                            })
                        }


                        if (childrensOfLi.length > 0) {
                            alert('it is not possible to move a menu item which has children');
                            return false;

                        }

                        dropE.attr('need-move', '1');

                        dropE.attr('top', topD);
                        dropE.attr('left', leftD)
                        //lop through other elements

                        jQuery('.list-item-menu li.item-menu').each(function(index, element) {
                            var position = jQuery(this).offset();
                            var top = position.top;

                            var left = position.left;
                            var id = $(this).attr('id');

                            var level = $(this).data('level');

                            var dataId = $(this).data('id');

                            var title = $(this).data('title');
                            var dataParent = $(this).data('parent');
                            var dataParentName = $(this).data('parentName');

                            var posData = {
                                top: top,
                                id: id,
                                left: left,
                                level:level,
                                dataId: dataId,
                                title: title,
                                parent: dataParent,
                                parentName: dataParentName
                            };

                            //find element that have level greater d and  level < D
                            // top is < D and top is smallest test
                            //left is < D
                            if (id != idD  && top > topD )  {
                                calArr.push(posData);
                            }

                            jQuery(this).attr('top', top);
                            jQuery(this).attr('left', left)


                        });

                        //find the object that has smallest top in the array

                        var minTop = Number.MAX_VALUE;

                        var minTopId =0;

                        if (calArr.length > 0)
                        {
                            for (var i = 0; i < calArr.length ; i++)
                            {
                                if (calArr.top < minTop)
                                {
                                    minTop = calArr.top;
                                    minTopId =i;
                                }

                            }

                        }

                        var sibObj = calArr[minTopId];

                        if (sibObj != undefined)
                        {
                            var sibId = sibObj.id;
                            var sibDataId  = sibObj.dataId;

                            var title  = sibObj.title;


                            //move the draggable and its child
                            $('li[need-move="1"]').insertBefore($('#'+ sibId));

                            //update parents by loop through the meu array
                            ko.utils.arrayForEach(self.menus(), function(item) {
                                var menuId = item.id();

                                if (dataIdD ==menuId) {
                                    if (sibObj.level > 0) {
                                        console.log(sibObj.id);
                                        item.parent(sibObj.parent);
                                        item.level(sibObj.level);
                                        item.hasParent(true);
                                        item.parentName(sibObj.parentName);
                                    } else {
                                        item.level(0);
                                        item.hasParent(false);
                                        item.parent(0);
                                    }

                                }

                            });

                            self.updateBrother();

                            $('li').attr('need-move',0);

                        }


                    }
                });

            },


            // Load initial state from server, convert it to Task instances, then populate self.tasks
            url.setBaseUrl(BASE_URL);
        var menuFeedUrl = self.config.loadMenuUrl;

        $.ajax({
            url: menuFeedUrl,
            data : {form_key: FORM_KEY}
        }).done(function(response) {

            var menusData = ko.utils.parseJson(response);
            var mappedMenus = $.map(menusData, function(item) { return new Menu(item) });
            self.menus(mappedMenus);
            self.menuLoading(false);
        } );


        // //Load the pages from ajax feed
        var pagesAjaxFeedUrl =  self.config.loadPageUrl;
        var pagesJson,catesJson;
        $.ajax({
            url: pagesAjaxFeedUrl,
            data : {form_key: FORM_KEY}
        }).done(function(response) {
            pagesJson = response;
            var pagesData = ko.utils.parseJson(pagesJson);
            var mappedPages = $.map(pagesData, function(item) { return new Page(item) });
            self.pages(mappedPages);
            self.pageLoading(false);
        } );




        //Load the categories from ajax feed
        var catAjaxFeedUrl = self.config.loadCategoriesUrl;
        $.ajax({
            url: catAjaxFeedUrl,
            data : {form_key: FORM_KEY}
        }).done(function(response) {
            catesJson = response;
            var catsData =ko.utils.parseJson(catesJson);
            var mappedCats = $.map(catsData, function(item) { return new Cat(item) });
            self.cats(mappedCats);
            self.catLoading(false);
        } );

        self.dragAndDrop(self);

    }

    return Class.extend({
        defaults: {
            /**
             * Initialized solutions
             */
            updateOption: true,
            config : {

                loadMenuUrl :'',
                loadPageUrl: '',
                loadCategoriesUrl: ''
            }
        },
        /**
         * Constructor
         */
        initialize: function (config) {
            var self = this;
            this.initConfig(config);

            this.bindAction(self);

        },
        bindAction:function(self) {
            var  $config = self.config;
            ko.cleanNode(document.getElementById("easyMegaMenu"));
            ko.cleanNode(document.getElementById("removed_items"));

            ko.applyBindings(new MenuViewModel($config),document.getElementById("easyMegaMenu"));


        }




    })
});